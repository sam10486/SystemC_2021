#include "HalfAdder.h"

void HalfAdder::runHalfAdder(){
	Sum = A ^ B;
	Carry = A & B;

}

