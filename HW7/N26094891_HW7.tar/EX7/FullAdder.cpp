#include "FullAdder.h"

void FullAdder::runOR(){
	Cout = c1|c2;
}